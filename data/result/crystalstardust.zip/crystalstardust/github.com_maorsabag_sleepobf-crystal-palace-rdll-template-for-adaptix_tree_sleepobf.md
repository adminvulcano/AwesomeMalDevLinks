# https://github.com/MaorSabag/SleepObf-Crystal-Palace-RDLL-template-for-Adaptix/tree/SleepObf

[Skip to content](https://github.com/MaorSabag/Adaptix-StealthPalace/tree/SleepObf#start-of-content)

You signed in with another tab or window. [Reload](https://github.com/MaorSabag/Adaptix-StealthPalace/tree/SleepObf) to refresh your session.You signed out in another tab or window. [Reload](https://github.com/MaorSabag/Adaptix-StealthPalace/tree/SleepObf) to refresh your session.You switched accounts on another tab or window. [Reload](https://github.com/MaorSabag/Adaptix-StealthPalace/tree/SleepObf) to refresh your session.Dismiss alert

{{ message }}

![](<Base64-Image-Removed>)

![404 “This is not the web page you are looking for”](<Base64-Image-Removed>)![](<Base64-Image-Removed>)![](<Base64-Image-Removed>)![](<Base64-Image-Removed>)![](<Base64-Image-Removed>)![](<Base64-Image-Removed>)![](<Base64-Image-Removed>)

Find code, projects, and people on GitHub:

Search

[Contact Support](https://support.github.com/?tags=dotcom-404) —
[GitHub Status](https://githubstatus.com/) —
[@githubstatus](https://twitter.com/githubstatus)

You can’t perform that action at this time.